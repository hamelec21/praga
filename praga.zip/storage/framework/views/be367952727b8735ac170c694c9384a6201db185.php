<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praga</title>
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Styles -->
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
</head>
<body class="fondo">
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('show-resultados')->html();
} elseif ($_instance->childHasBeenRendered('pSiTUgm')) {
    $componentId = $_instance->getRenderedChildComponentId('pSiTUgm');
    $componentTag = $_instance->getRenderedChildComponentTagName('pSiTUgm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pSiTUgm');
} else {
    $response = \Livewire\Livewire::mount('show-resultados');
    $html = $response->html();
    $_instance->logRenderedChild('pSiTUgm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>




<!--menu-->
<?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
<?php echo \Livewire\Livewire::scripts(); ?>

</html>
<?php /**PATH F:\laragon\www\praga\resources\views/resultados.blade.php ENDPATH**/ ?>