<div class=" flex  px-4 mx-auto  bg-gray-800 py-2  w-full fixed top-0 left-0 right-0">
    <img src="img/logo/logo.png" class="mx-auto h-14 md:h-14 lg:h-14">
</div>
<?php /**PATH E:\laragon\www\LARAVEL\praga\resources\views/header.blade.php ENDPATH**/ ?>