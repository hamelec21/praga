<!DOCTYPE html>
<html>
<head>
    <title>Praga</title>
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Styles -->
    <?php echo \Livewire\Livewire::styles(); ?>


</head>
<body class="bg-gray-900 ">
<!--header-->
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--contenido-->

<div class="h-min py-20">

    <!--fecha-->
    <div class="container mx-auto mt-3 mb-3 px-4">
        <div class="text-center text-gray-200 px-4 py-2 bg-gray-800  mx-auto rounded-lg shadow-xl uppercase">
            Resultados
            Fecha 18 Infantil
        </div>
    </div>

    <!--resultados infantiles-->

    <div class="container mx-auto mt-2 mb-4">
        <div class="text-center text-gray-200 px-4 py-2   mx-auto ">
            <div class="bg-gray-800 mx-auto rounded-lg py-1 mb-2">
                <div class="mb-1 text-md">Tercera</div>
                <div class="flex flex-rows justify-around ">
                    <div><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-1 text-md">3</div>
                    <div class="py-1 text-md">-</div>
                    <div class="py-1 text-md">1</div>
                    <div><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="mb-2 text-md text-green-400">Finalizado</div>
            </div>

            <div class="bg-gray-800 mx-auto rounded-lg py-1 mb-2">
                <div class="mb-1 text-md">Segunda</div>
                <div class="flex flex-rows justify-around ">
                    <div><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-1 text-md">3</div>
                    <div class="py-1 text-md">-</div>
                    <div class="py-1 text-md">1</div>
                    <div><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="mb-2 text-md text-green-400">Finalizado</div>
            </div>

            <div class="bg-gray-800 mx-auto rounded-lg py-1 mb-2">
                <div class="mb-1 text-md">Primera</div>
                <div class="flex flex-rows justify-around ">
                    <div><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-1 text-md">3</div>
                    <div class="py-1 text-md">-</div>
                    <div class="py-1 text-md">1</div>
                    <div><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="mb-2 text-md text-green-400">Finalizado</div>
            </div>

        </div>
    </div>

    <!--resultados adultos-->

    <div class="container mx-auto mt-3 mb-4 px-4">
        <div class="text-center text-gray-200 px-4 py-2 bg-gray-800  mx-auto rounded-lg shadow-xl uppercase">
            Resultados
            Adultos Fecha 18
        </div>
    </div>

    <div class="container mx-auto mt-2 mb-2">
        <div class="text-center text-gray-200 px-4 py-2 mx-auto ">
            <div class="bg-gray-800 mx-auto rounded-lg py-1 mb-2">
                <div class="mb-1 text-md">Tercera</div>
                <div class="flex flex-rows justify-around ">
                    <div><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-1 text-md">3</div>
                    <div class="py-1 text-md">-</div>
                    <div class="py-1 text-md">1</div>
                    <div><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="mb-2 text-md text-green-400">Finalizado</div>
            </div>

            <div class="bg-gray-800 mx-auto rounded-lg py-1 mb-2">
                <div class="mb-1 text-md">Segunda</div>
                <div class="flex flex-rows justify-around ">
                    <div><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-1 text-md">3</div>
                    <div class="py-1 text-md">-</div>
                    <div class="py-1 text-md">1</div>
                    <div><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="mb-2 text-md text-green-400">Finalizado</div>
            </div>

            <div class="bg-gray-800 mx-auto rounded-lg py-1 mb-2">
                <div class="mb-1 text-md">Senior</div>
                <div class="flex flex-rows justify-around ">
                    <div><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-1 text-md">3</div>
                    <div class="py-1 text-md">-</div>
                    <div class="py-1 text-md">1</div>
                    <div><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="mb-2 text-md text-green-400">Finalizado</div>
            </div>

            <div class="bg-gray-800  mx-auto rounded-lg py-2 mb-2">
                <div class="mb-2 text-md">Primera</div>
                <div class="flex flex-rows justify-around ">
                    <div><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">4</div>
                    <div class="py-2 text-md">-</div>
                    <div class="py-2 text-md">1</div>
                    <div><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="mb-2 text-md text-green-400">Finalizado</div>
            </div>

        </div>
    </div>


    <!--Resultados femeninas-->

    <div class="container mx-auto mt-2 mb-4 px-4">
        <div class="text-center text-gray-200 px-4 py-2 bg-gray-800  mx-auto rounded-lg shadow-xl uppercase">
            Resultados
            Femeninas Fecha 18
        </div>
    </div>

    <div class="container mx-auto mt-2 mb-2">
        <div class="text-center text-gray-200 px-4 py-2  mx-auto ">
            <div class="bg-gray-800  mx-auto rounded-lg py-2 mb-2">
                <div class="mb-2 text-md">Femenina</div>
                <div class="flex flex-rows justify-around ">
                    <div><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">4</div>
                    <div class="py-2 text-md">-</div>
                    <div class="py-2 text-md">1</div>
                    <div><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="mb-2 text-md text-green-400">Finalizado</div>
            </div>
        </div>
    </div>

    <!--Resultados sub 45-->

    <div class="container mx-auto mt-2 mb-4 px-4 ">
        <div class="text-center text-gray-200 px-4 py-2 bg-gray-800  mx-auto rounded-lg shadow-xl uppercase">
            Resultado
            Sub 45 Fecha 18
        </div>
    </div>

    <div class="container mx-auto mt-2 mb-2">
        <div class="text-center text-gray-200 px-4 py-2  mx-auto ">
            <div class="bg-gray-800  mx-auto rounded-lg py-2 mb-2">
                <div class="mb-2 text-md">Sub 45</div>
                <div class="flex flex-rows justify-around ">
                    <div><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">4</div>
                    <div class="py-2 text-md">-</div>
                    <div class="py-2 text-md">1</div>
                    <div><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="mb-2 text-md text-green-400">Finalizado</div>
            </div>
        </div>
    </div>

</div>


<!--menu-->
<?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>
<?php echo \Livewire\Livewire::scripts(); ?>

</html>
<?php /**PATH E:\laragon\www\LARAVEL\praga\resources\views/resultados.blade.php ENDPATH**/ ?>