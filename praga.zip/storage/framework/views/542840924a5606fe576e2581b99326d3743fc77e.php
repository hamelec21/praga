<!DOCTYPE html>
<html>
<head>
    <title>Praga</title>
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Styles -->
    <?php echo \Livewire\Livewire::styles(); ?>


</head>
<body class="bg-gray-900 ">
<!--header-->
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!--contenido-->

<div class="h-min py-20">

    <!--fecha-->
    <div class="container mx-auto mt-5 mb-5">
        <div
            class=" font-bold text-center text-gray-400 px-4 py-2 bg-gray-800 w-4/5 mx-auto rounded-lg shadow-xl uppercase">
            fixture 2023
        </div>
    </div>



    <!--Fixture-->

    <div class="container mx-auto ">

        <div class="grid grid-cols-2  md:grid-cols-6 lg:grid-cols-6 gap-2 ml-4 mr-4">

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class=" text-sm text-center py-1 rounded-lg text-gray-500 font-bold">Primera Rueda 2023</div>
                <div class="text-sm text-center py-1 text-gray-400 font-bold">Fecha 1 </div>
                <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">Domingo 05 de Marzo</div>
                <div class="flex flex-rows justify-around py-4">
                    <div class="py-1"><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">V/S</div>
                    <div class="py-1"><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4">Local</div>

                <div class="text-sm text-center text-md rounded-lg bg-sky-700 ml-4 mr-4 mt-5">Jugado</div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class=" text-sm text-center py-1 rounded-lg text-gray-500 font-bold">Primera Rueda 2023</div>
                <div class="text-sm text-center py-1 text-gray-400 font-bold">Fecha 2 </div>
                <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">Domingo 12 de Marzo</div>
                <div class="flex flex-rows justify-around py-4">
                    <div class="py-1"><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">V/S</div>
                    <div class="py-1"><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4">Visita</div>

                <div class="text-sm text-center text-md rounded-lg bg-sky-700 ml-4 mr-4 mt-5">Jugado</div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class=" text-sm text-center py-1 rounded-lg text-gray-500 font-bold">Primera Rueda 2023</div>
                <div class="text-sm text-center py-1 text-gray-400 font-bold">Fecha 3 </div>
                <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">Domingo 19 de Marzo</div>
                <div class="flex flex-rows justify-around py-4">
                    <div class="py-1"><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">V/S</div>
                    <div class="py-1"><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4">Local</div>

                <div class="text-sm text-center text-md rounded-lg bg-red-700 ml-4 mr-4 mt-5">Suspendido</div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class=" text-sm text-center py-1 rounded-lg text-gray-500 font-bold">Primera Rueda 2023</div>
                <div class="text-sm text-center py-1 text-gray-400 font-bold">Fecha 4 </div>
                <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">Domingo 26 de Marzo</div>
                <div class="flex flex-rows justify-around py-4">
                    <div class="py-1"><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">V/S</div>
                    <div class="py-1"><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4">Visita</div>

                <div class="text-sm text-center text-md rounded-lg bg-green-700 ml-4 mr-4 mt-5">Programado</div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class=" text-sm text-center py-1 rounded-lg text-gray-500 font-bold">Primera Rueda 2023</div>
                <div class="text-sm text-center py-1 text-gray-400 font-bold">Fecha 5 </div>
                <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">Domingo 02 de Abril</div>
                <div class="flex flex-rows justify-around py-4">
                    <div class="py-1"><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">V/S</div>
                    <div class="py-1"><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4">Local</div>

                <div class="text-sm text-center text-md rounded-lg bg-green-700 ml-4 mr-4 mt-5">Programado</div>

            </div>


            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class=" text-sm text-center py-1 rounded-lg text-gray-500 font-bold">Primera Rueda 2023</div>
                <div class="text-sm text-center py-1 text-gray-400 font-bold">Fecha 6 </div>
                <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">Domingo 09 de Abril</div>
                <div class="flex flex-rows justify-around py-4">
                    <div class="py-1"><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">V/S</div>
                    <div class="py-1"><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4">visita</div>

                <div class="text-sm text-center text-md rounded-lg bg-green-700 ml-4 mr-4 mt-5">Programado</div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class=" text-sm text-center py-1 rounded-lg text-gray-500 font-bold">Primera Rueda 2023</div>
                <div class="text-sm text-center py-1 text-gray-400 font-bold">Fecha 7 </div>
                <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">Domingo 16 de Abril </div>
                <div class="flex flex-rows justify-around py-4">
                    <div class="py-1"><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">V/S</div>
                    <div class="py-1"><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4">Local</div>

                <div class="text-sm text-center text-md rounded-lg bg-green-700 ml-4 mr-4 mt-5">Programado</div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class=" text-sm text-center py-1 rounded-lg text-gray-500 font-bold">Primera Rueda 2023</div>
                <div class="text-sm text-center py-1 text-gray-400 font-bold">Fecha 8 </div>
                <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">Domingo 23 de Abril</div>
                <div class="flex flex-rows justify-around py-4">
                    <div class="py-1"><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">V/S</div>
                    <div class="py-1"><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4">Visita</div>

                <div class="text-sm text-center text-md rounded-lg bg-green-700 ml-4 mr-4 mt-5">Programado</div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class=" text-sm text-center py-1 rounded-lg text-gray-500 font-bold">Primera Rueda 2023</div>
                <div class="text-sm text-center py-1 text-gray-400 font-bold">Fecha 9 </div>
                <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">Domingo 30 de Abril</div>
                <div class="flex flex-rows justify-around py-4">
                    <div class="py-1"><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">V/S</div>
                    <div class="py-1"><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4">Local</div>

                <div class="text-sm text-center text-md rounded-lg bg-green-700 ml-4 mr-4 mt-5">Programado</div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class=" text-sm text-center py-1 rounded-lg text-gray-500 font-bold">Primera Rueda 2023</div>
                <div class="text-sm text-center py-1 text-gray-400 font-bold">Fecha 10 </div>
                <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">Domingo 07 de Mayo</div>
                <div class="flex flex-rows justify-around py-4">
                    <div class="py-1"><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">V/S</div>
                    <div class="py-1"><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4">Visita</div>

                <div class="text-sm text-center text-md rounded-lg bg-green-700 ml-4 mr-4 mt-5">Programado</div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class=" text-sm text-center py-1 rounded-lg text-gray-500 font-bold">Primera Rueda 2023</div>
                <div class="text-sm text-center py-1 text-gray-400 font-bold">Fecha 11 </div>
                <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">Domingo 14 de Mayo</div>
                <div class="flex flex-rows justify-around py-4">
                    <div class="py-1"><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">V/S</div>
                    <div class="py-1"><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4">Local</div>

                <div class="text-sm text-center text-md rounded-lg bg-green-700 ml-4 mr-4 mt-5">Programado</div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class=" text-sm text-center py-1 rounded-lg text-gray-500 font-bold">Primera Rueda 2023</div>
                <div class="text-sm text-center py-1 text-gray-400 font-bold">Fecha 12 </div>
                <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">Domingo 21 de Mayo</div>
                <div class="flex flex-rows justify-around py-4">
                    <div class="py-1"><img src="img/logos_equipos/cd_carmelo.png" class="h-10"></div>
                    <div class="py-2 text-md">V/S</div>
                    <div class="py-1"><img src="img/logos_equipos/cd_penarol.png" class="h-10"></div>
                </div>
                <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4">Visita</div>

                <div class="text-sm text-center text-md rounded-lg bg-green-700 ml-4 mr-4 mt-5">Programado</div>

            </div>

        </div>


    </div>


    <!--menu-->
<?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<?php echo \Livewire\Livewire::scripts(); ?>

</html>
<?php /**PATH E:\laragon\www\LARAVEL\praga\resources\views/fixture.blade.php ENDPATH**/ ?>