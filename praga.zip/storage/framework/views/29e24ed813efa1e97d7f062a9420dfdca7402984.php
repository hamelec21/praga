<!DOCTYPE html>
<html>
<head>
    <title>Praga</title>
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Styles -->
    <?php echo \Livewire\Livewire::styles(); ?>


</head>
<body class="bg-gray-900 ">
<!--logo-->
<div class="  flex  px-4 mx-auto  bg-slate-800 py-2  w-full fixed">
    <img src="img/logo/logo.png" class="mx-auto h-14 md:h-14 lg:h-14">
</div>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<!--pie-->
<div class="mt-32">

    <div class="flex  justify-around px-4 mx-auto  bg-slate-800 py-3 text-center">
        <div class="text-white">
            <i class="fa-regular fa-futbol fa-2x"></i>
            <div class="text-xs">Home</div>
        </div>

        <div class="text-white">
            <i class="fa-solid fa-trophy fa-2x"></i>
            <div class=" text-xs">Resultados</div>
        </div>

        <div class="text-white">
            <i class="fa-solid fa-calendar-days fa-2x"></i>
            <div class=" text-xs">Programación</div>
        </div>

        <div class="text-white">
            <i class="fa-solid fa-bell fa-2x"></i>
            <div class=" text-xs">Notificaciónes</div>
        </div>



    </div>



</div>





</body>
<?php echo \Livewire\Livewire::scripts(); ?>

</html>
<?php /**PATH E:\laragon\www\LARAVEL\praga\resources\views/infantiles.blade.php ENDPATH**/ ?>