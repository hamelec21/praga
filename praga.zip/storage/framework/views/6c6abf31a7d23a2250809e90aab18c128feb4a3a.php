<div>
    
</div>
<?php /**PATH E:\laragon\www\LARAVEL\praga\resources\views/livewire/panel/configuraciones/serie/show.blade.php ENDPATH**/ ?>