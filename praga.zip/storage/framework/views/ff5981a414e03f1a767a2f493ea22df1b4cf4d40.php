<!DOCTYPE html>
<html>
<head>
    <title>Praga</title>
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Styles -->
    <?php echo \Livewire\Livewire::styles(); ?>


</head>
<body class="bg-gray-900 ">
<!--header-->
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!--contenido-->

<div class="h-min py-20">


    <!--Fixture-->

    <div class="container mx-auto mt-5 mb-5">

        <div class="grid grid-cols-1 px-4 gap-2">

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class="flex flex-row justify-around mt-1">
                    <div class=" text-sm text-gray-500  font-bold uppercase">Informativo</div>
                    <div class=" text-sm text-gray-500  font-bold uppercase">18 Marzo 2023</div>
                </div>


                <div class=" text-sm text-center py-1 rounded-lg text-gray-500  font-bold mt-2">

                    <p class="text-white text-center px-4 text-sm">Suspendida Fecha Numero 3 por Mal Tiempo
                    </p>

                </div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class="flex flex-row justify-around mt-1">
                    <div class=" text-sm text-gray-500  font-bold uppercase">Informativo</div>
                    <div class=" text-sm text-gray-500  font-bold uppercase">18 Marzo 2023</div>
                </div>


                <div class=" text-sm text-center py-1 rounded-lg text-gray-500  font-bold mt-2">

                    <p class="text-white text-center px-4 text-sm">Suspendida Fecha Numero 3 por Mal Tiempo
                    </p>

                </div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class="flex flex-row justify-around mt-1">
                    <div class=" text-sm text-gray-500  font-bold uppercase">Informativo</div>
                    <div class=" text-sm text-gray-500  font-bold uppercase">18 Marzo 2023</div>
                </div>


                <div class=" text-sm text-center py-1 rounded-lg text-gray-500  font-bold mt-2">

                    <p class="text-white text-center px-4 text-sm">Suspendida Fecha Numero 3 por Mal Tiempo
                    </p>

                </div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class="flex flex-row justify-around mt-1">
                    <div class=" text-sm text-gray-500  font-bold uppercase">Informativo</div>
                    <div class=" text-sm text-gray-500  font-bold uppercase">18 Marzo 2023</div>
                </div>


                <div class=" text-sm text-center py-1 rounded-lg text-gray-500  font-bold mt-2">

                    <p class="text-white text-center px-4 text-sm">Suspendida Fecha Numero 3 por Mal Tiempo
                    </p>

                </div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class="flex flex-row justify-around mt-1">
                    <div class=" text-sm text-gray-500  font-bold uppercase">Informativo</div>
                    <div class=" text-sm text-gray-500  font-bold uppercase">18 Marzo 2023</div>
                </div>


                <div class=" text-sm text-center py-1 rounded-lg text-gray-500  font-bold mt-2">

                    <p class="text-white text-center px-4 text-sm">Suspendida Fecha Numero 3 por Mal Tiempo
                    </p>

                </div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class="flex flex-row justify-around mt-1">
                    <div class=" text-sm text-gray-500  font-bold uppercase">Informativo</div>
                    <div class=" text-sm text-gray-500  font-bold uppercase">18 Marzo 2023</div>
                </div>


                <div class=" text-sm text-center py-1 rounded-lg text-gray-500  font-bold mt-2">

                    <p class="text-white text-center px-4 text-sm">Suspendida Fecha Numero 3 por Mal Tiempo
                    </p>

                </div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class="flex flex-row justify-around mt-1">
                    <div class=" text-sm text-gray-500  font-bold uppercase">Informativo</div>
                    <div class=" text-sm text-gray-500  font-bold uppercase">18 Marzo 2023</div>
                </div>


                <div class=" text-sm text-center py-1 rounded-lg text-gray-500  font-bold mt-2">

                    <p class="text-white text-center px-4 text-sm">Suspendida Fecha Numero 3 por Mal Tiempo
                    </p>

                </div>

            </div>

            <div class="flex flex-col bg-gray-800  rounded-lg text-white py-4">

                <div class="flex flex-row justify-around mt-1">
                    <div class=" text-sm text-gray-500  font-bold uppercase">Informativo</div>
                    <div class=" text-sm text-gray-500  font-bold uppercase">18 Marzo 2023</div>
                </div>


                <div class=" text-sm text-center py-1 rounded-lg text-gray-500  font-bold mt-2">

                    <p class="text-white text-center px-4 text-sm">Suspendida Fecha Numero 3 por Mal Tiempo
                    </p>

                </div>

            </div>

        </div>


    </div>


    <!--menu-->
<?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<?php echo \Livewire\Livewire::scripts(); ?>

</html>
<?php /**PATH E:\laragon\www\LARAVEL\praga\resources\views/notificaciones.blade.php ENDPATH**/ ?>