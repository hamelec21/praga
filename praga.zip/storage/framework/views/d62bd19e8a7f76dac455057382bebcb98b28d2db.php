<div>
    <!--contenido-->

    <div class="h-min py-20">

        <!--fecha-->
        <div class="container mx-auto mt-5 mb-5 w-3/5 py-3">
            <div
                class="font-bold text-center text-gray-800 px-4 py-2 bg-white  mx-auto rounded-lg shadow-xl uppercase">
                fixture 2023
            </div>
        </div>

        <!--Fixture-->
        <div class="container mx-auto">
            <div class="grid grid-cols-1  md:grid-cols-2 lg:grid-cols-6 gap-4 ml-4 mr-4">
                <?php $__currentLoopData = $fixtures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fixture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col bg-white  rounded-lg text-white py-4 ">
                    <div class=" text-sm text-center py-1 rounded-lg text-gray-700 font-bold"><?php echo e($fixture->temporada->nombre); ?> 2023</div>
                    <div class="text-sm text-center py-1 text-gray-700 font-bold">Fecha <?php echo e($fixture->fechas_id); ?></div>
                    <div class=" text-sm text-center py-1 rounded-lg bg-gray-900 ml-4 mr-4">
                            <?php
                            $date = \Carbon\Carbon::parse($fixture->fecha)->locale('es');
                            echo $date->translatedFormat( 'l j F' );
                            ?>
                    </div>

                    <div class="flex flex-rows justify-center py-2 gap-x-4">
                        <div class="py-1"><img src="<?php echo e(Storage::url($fixture->logo->logo)); ?>" class="h-10"></div>
                        <div class="py-3 text-md text-gray-900 font-bold">V/S</div>
                        <div class="py-1"><img src="<?php echo e(Storage::url($fixture->log->logo)); ?>" class="h-10"></div>
                    </div>
                    <div class="flex flex-row justify-around mb-5 px-2">
                        <div class="flex flex-col text-gray-800 text-xs font-bold"><?php echo e($fixture->club->nombre); ?></div>
                        <div class="flex flex-col text-gray-800 text-xs font-bold"><?php echo e($fixture->eq->nombre); ?></div>
                    </div>
                    <div class="text-sm text-center text-md rounded-lg bg-gray-900 ml-4 mr-4 "><?php echo e($fixture->juega); ?></div>
                    
                    <div class="">
                        <?php if($fixture->estado->status === 'Programado'): ?>
                            <!--Programado-->
                            <div
                                class="text-sm text-center text-md rounded-lg bg-green-700 ml-4 mr-4 mt-5">
                                <?php echo e($fixture->estado->status); ?>

                            </div>
                        <?php elseif($fixture->estado->status === 'Suspendido'): ?>
                            <!--Suspendido-->
                            <div
                                class="text-sm text-center text-md rounded-lg bg-red-700 ml-4 mr-4 mt-5">
                                <?php echo e($fixture->estado->status); ?>

                            </div>

                        <?php elseif($fixture->estado->status === 'Jugado'): ?>
                            <!--Suspendido-->
                            <div
                                class="text-sm text-center text-md rounded-lg bg-sky-700 ml-4 mr-4 mt-5">
                                <?php echo e($fixture->estado->status); ?>

                            </div>

                        <?php elseif($fixture->estado->status === 'Finalizado'): ?>
                            <!--Suspendido-->
                            <div
                                class="text-sm text-center text-md rounded-lg bg-indigo-600 ml-4 mr-4 mt-5">
                                <?php echo e($fixture->estado->status); ?>

                            </div>


                        <?php endif; ?>

                    </div>




                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</div>

<?php /**PATH F:\laragon\www\praga\resources\views/livewire/show-fixure.blade.php ENDPATH**/ ?>