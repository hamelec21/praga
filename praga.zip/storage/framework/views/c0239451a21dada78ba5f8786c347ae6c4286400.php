<!DOCTYPE html>
<html>
<head>
    <title>Praga</title>
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Styles -->
    <?php echo \Livewire\Livewire::styles(); ?>


</head>
<body class="bg-gray-900 min-h-screen">

<!--logo-->
<div class=" container flex  px-4 mx-auto mt-20 lg:mt-20 ">
    <img src="<?php echo e(asset('img/logo/logo.png')); ?>" class="mx-auto h-60 md:h-48 lg:h-44">
</div>



<!--boton entrar-->
<div class="mt-20 px-4">
    <a href="resultados">
        <button class="text-sm text-white  w-full   px-8 py-4 rounded-lg bg-slate-800 hover:bg-slate-700 ">ENTRAR
        </button>
    </a>

</div>


<!--pie-->

<div class="text-gray-800 mt-44 text-center">JR Developer 2023</div>







</body>
<?php echo \Livewire\Livewire::scripts(); ?>

</html>
<?php /**PATH E:\laragon\www\LARAVEL\praga\resources\views/welcome.blade.php ENDPATH**/ ?>