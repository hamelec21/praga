<div class="mt-20 fixed bottom-0 w-full">
    <div class="flex  justify-around px-4 mx-auto bg-gray-800 py-3 text-center">
        <div class="text-white">
            <a href="/">
                <i class="fa-regular fa-futbol fa-2x"></i>
                <div class="text-xs">Home</div>
            </a>
        </div>

        <div class="text-white">
            <a href="resultados">
                <i class="fa-solid fa-trophy fa-2x"></i>
                <div class=" text-xs">Resultados</div>
            </a>
        </div>

        <div class="text-white">
            <a href="fixture">
                <i class="fa-solid fa-calendar-days fa-2x"></i>
                <div class=" text-xs">Fixture</div>
            </a>
        </div>


        <div class="text-white">
            <a href="notificaciones">
                <div class="rounded-xl border-slate-900">
                    <div
                        class="rounded-full bg-red-600 text-center text-white font-bold  text-xs w-4 h-4 ml-4 -mt-1">
                        6
                    </div>
                    <i class="fa-solid fa-bell fa-2x -mt-4 "></i>
                    <div class=" text-xs ">Notificaciónes</div>
                </div>
            </a>
        </div>


    </div>


</div>

<?php /**PATH E:\laragon\www\LARAVEL\praga\resources\views/menu.blade.php ENDPATH**/ ?>