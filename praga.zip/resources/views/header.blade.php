<div class=" flex  px-4 mx-auto  bg-gray-800 py-2  w-full fixed top-0 left-0 right-0 justify-around">
    <div class="">
        <img src="img/logo/logo.png" class="mx-auto h-14 md:h-14 lg:h-14">
    </div>

    <div class="px-4">
        <a href="notificaciones">
            <div class="rounded-xl border-slate-900">

                <div
                    class="rounded-full bg-red-600 text-center text-white font-bold  text-md w-6 h-6 ml-4 mt-1">
                    1
                </div>
                <i class="fa-solid fa-bell fa-2x -mt-4  text-white"></i>

            </div>
        </a>
    </div>

</div>


