<?php

namespace App\Http\Livewire\Menu;

use Livewire\Component;

class Header extends Component
{
    public function render()
    {
        return view('livewire.menu.header');
    }
}
