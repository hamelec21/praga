<?php

namespace App\Http\Livewire\Menu;

use Livewire\Component;

class Sidebar extends Component
{
    public function render()
    {
        return view('livewire.menu.sidebar');
    }
}
